# paystack-integration
Integration of paystack payment gateway using PHP, HTML, CSS and HTML
Instruction: 
1. All the files you need for the project is found in the folder named "Payment"
2. Copy that folder into you server eg htdocs in XAMPP.
3. The Database code is in the file named "payment.sql"
Note: We have premuim courses where projects like User subbscription application, Donation page, multiple product sales page etc are built out of paystack.
If you want it, contact us via email => thelordofapps@gmail.com

