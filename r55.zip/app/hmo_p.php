<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class hmo_p extends Model
{
    // // Table name
    protected $table = 'hmo_ps';
    // primary key
    public $primaryKey = 'id';
    //timestamps
    public $timestamps = true;
}
