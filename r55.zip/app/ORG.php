<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ORG extends Model
{
    //
       // Table name
       protected $table = 'o_r_g_s';
       // primary key
       public $primaryKey = 'id';
       //timestamps
       public $timestamps = true;
}
