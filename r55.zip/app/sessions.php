<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class sessions extends Model
{
    //
    protected $table = 'sessions';
    // primary key
    public $primaryKey = 'id';
}
