<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HospitalDoctors extends Model
{
    //
    
    protected $table = 'hospital_doctors';
    // primary key
    public $primaryKey = 'id';
}
