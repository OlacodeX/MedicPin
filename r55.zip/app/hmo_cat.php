<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class hmo_cat extends Model
{
    //
     // Table name
     protected $table = 'hmo_cats';
     // primary key
     public $primaryKey = 'id';
     //timestamps
     public $timestamps = true;
}
