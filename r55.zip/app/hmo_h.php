<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class hmo_h extends Model
{
    //
       // Table name
       protected $table = 'hmo_hs';
       // primary key
       public $primaryKey = 'id';
       //timestamps
       public $timestamps = true;
}
