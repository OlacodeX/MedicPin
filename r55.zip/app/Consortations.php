<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Consortations extends Model
{
    //
    protected $table = 'consortations';
    // primary key
    public $primaryKey = 'id';
}
