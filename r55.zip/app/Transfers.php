<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Transfers extends Model
{
    //
   
    // Table name
    protected $table = 'transfers';
    // primary key
    public $primaryKey = 'id';
    //timestamps
    public $timestamps = true;


}
