<?php $__env->startSection('content'); ?>
<?php echo $__env->make('inc.navmain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <!-- Page Content  -->
     <div>
        <div class="">
                <div class="iq-card">
                        <?php echo Form::open(['action' => 'PatientsController@store_transfer', 'method' => 'POST']) /** The action should be the block of code in the store function in PostsController
                        **/; ?>

                       <div class="iq-card-header d-flex justify-content-between">
                          <div class="iq-header-title">
                             <h4 class="card-title">Transfer Patient With MedicPin <?php echo $patient->pin; ?> To Another Doctor</h4>
                          </div>
                       </div>
                       <div class="iq-card-body">
                                <hr>
                                <div class="">
                                    <div class="form-group">
                                       <label for="patient">Transfer To</label>
                                       <input type="hidden" class="form-control" name="pin" value="<?php echo e($patient->pin); ?>">
                                       <input type="hidden" class="form-control" name="name" value="<?php echo e($patient->name); ?>">
                                       <input type="hidden" class="form-control" name="from" value="<?php echo e($patient->doctor); ?>">
                                       <input type="hidden" class="form-control" name="from_email" value="<?php echo e($patient->doc_email); ?>">
                                       <div class="inner-addon right-addon">
                                           <i class="fa fa-paperclip"></i>
                                      
                                       <input type="text" class="form-control" name="doc_pin" placeholder="Enter Doctor's MedicPin ">
                                       </div>
                                    </div>
                                    <div class="form-group">
                                       <label for="note">Note To Doctor</label>
                                       <textarea class="form-control" id="note" name="note" placeholder="Special Message/Instructions To Doctor..." rows="8"></textarea>
                                    </div>
                                <button type="submit" class="btn btn-primary">Transfer Patient</button>
                                <?php echo Form::close(); ?>

                          </div>
                       </div>
                    </div>
              </div>
     <!-- Wrapper END -->
      <!-- Footer -->
        <footer class="bg-white iq-footer">
           <div class="container-fluid">
              <div class="row">
                 <div class="col-lg-6">
                    <ul class="list-inline mb-0">
                       <li class="list-inline-item"><a href="privacy-policy.html">Privacy Policy</a></li>
                       <li class="list-inline-item"><a href="terms-of-service.html">Terms of Use</a></li>
                    </ul>
                 </div>
                 <div class="col-lg-6 text-right">
                    Copyright 2020 <a href="./">Medicpin</a> All Rights Reserved.
                 </div>
              </div>
           </div>
        </footer>
        <!-- Footer END -->
         <script src="<?php echo e(URL::asset('../vendor/unisharp/laravel-ckeditor/ckeditor.js')); ?>"></script>
         <script>
            CKEDITOR.replace( 'note' );
         </script> 
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Medicpin\resources\views/patients/transfer.blade.php ENDPATH**/ ?>