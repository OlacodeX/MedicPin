<?php $__env->startSection('content'); ?>
<?php echo $__env->make('inc.navmain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div>
    <div class="">
    <div class="row">
    <div class="col-sm-12" style="text-align:justify; margin-top:30px;">
      <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      
      <div class="iq-card iq-card-block iq-card-stretch iq-card-height">
        <div class="iq-card-header d-flex justify-content-between">
           <div class="iq-header-title">
              <h4 class="card-title">Your Staff List </h4>
           </div>
           <div class="iq-card-header-toolbar d-flex align-items-center">
             <div class="dropdown">
                <span class="dropdown-toggle text-primary" id="dropdownMenuButton5" data-toggle="dropdown">
                <i class="ri-more-fill"></i>
                </span>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButton5">
                   <a class="dropdown-item" href="./add_staff"><i class="las la-radiation"></i>Add New Staff</a>
                </div>
             </div>
           </div>
        </div>
        <div class="iq-card-body">
           <div class="table-responsive">
            <?php if(count($users) > 0): ?>
           <table class="table mb-0 table-borderless">
              <thead>
                 <tr>
                  <th scope="col">Staff Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">HMO</th>
                    <th scope="col">HMO Package On</th>
                    <th scope="col">HMO Package Value</th>
                    <th scope="col">Address</th>
                    <th scope="col">Action</th>

                 </tr>
              </thead>
              <tbody>
                  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <?php
                        $hmo_user = App\hmo_p::where('user_name',$user->email)->first();
                    ?>
                    <?php if(!empty($hmo_user)): ?>
                    <?php
                        $hmo_details = App\User::where('id', $hmo_user->hmo)->first();
                        $package_name = App\HMO::where('id',$hmo_user->package_on )->first();
                    ?>
                        <td><?php echo e($hmo_details->hmo_org_name); ?></td>
                        <td><?php echo e($package_name->name); ?></td>
                        <td><?php echo $package_name->description; ?></td>
                    <?php else: ?>
                    <td>N/A</td>
                    <td>N/A</td>
                    <td>N/A</td>
                        
                    <?php endif; ?>
                    <td><?php echo e($user->address); ?></td>
                    <td>
                      <div class="dropdown">
                         <span class="dropdown-toggle text-primary" id="dropdownMenuButton5" data-toggle="dropdown">
                         <i class="ri-more-fill"></i>
                         </span>
                         <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButton5">
                         <a class="dropdown-item">
                            <?php echo Form::open(['action' => 'HmoController@add', 'method' => 'POST', 'id' => 'my_form_1', 'style' => 'margin-right:20px;']); ?>

                            <?php echo e(Form::hidden('email', $user->email)); ?>

                            <?php
                                $package = App\User::where('email',$user->email)->first();
                            ?>
                            <?php if($package->hmo_package == ''): ?>
                            <button type="submit" class ="btn btn-info btn-sm" data-toggle="tooltip" data-placement="top" data-original-title="Add Staff To HMO Package"><i class="fa fa-plus mr-2"></i>Add to HMO package</button>
                               
                            <?php else: ?>
                            <button type="submit" class ="btn btn-info btn-sm" data-toggle="tooltip" data-placement="top" data-original-title="Upgrade/Downgrade HMO Package"><i class="fa fa-plus mr-2"></i>Upgrade/Downgrade HMO package</button>
                             <?php endif; ?>
                            <?php echo Form::close(); ?>

                         </a>
                         <a class="dropdown-item">
                         <?php echo Form::open(['action' => ['HmoController@destroy', $user->id], 'method' => 'POST', 'id' => 'my_form_1', 'style' => 'margin-right:20px;']); ?>

                         <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                        <button type="submit" class ="btn btn-info btn-sm pull-right" data-toggle="tooltip" data-placement="top" data-original-title="Remove Staff From Organization"><i class="fa fa-trash-o mr-2"></i>Remove Staff From Organization</button>
                       
                        <?php echo Form::close(); ?>

                         </a>
                         </div>
                      </div>
                        
                    </td>
                 </tr>
                
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
           </table>
               
         <div class="col-md-6">
             <div style="text-align:right;">
                     <!-----The pagination link----->
                     <?php echo e($users->links()); ?>

             </div>
         </div>
             <?php else: ?>
             <p>No Record Found</p>   
           <?php endif; ?>
           </div>
        </div>
     </div>
  </div>
</div>

          <script src="<?php echo e(URL::asset('../vendor/unisharp/laravel-ckeditor/ckeditor.js')); ?>"></script>
          <script>
              CKEDITOR.replace( 'pre' );
          </script> 
     <!-- Wrapper END -->
      <!-- Footer -->
        <footer class="bg-white iq-footer" style="margin-top:280px;">
           <div class="container-fluid">
              <div class="row">
                 <div class="col-lg-6">
                    <ul class="list-inline mb-0">
                       <li class="list-inline-item"><a href="privacy-policy.html">Privacy Policy</a></li>
                       <li class="list-inline-item"><a href="terms-of-service.html">Terms of Use</a></li>
                    </ul>
                 </div>
                 <div class="col-lg-6 text-right">
                    Copyright 2020 <a href="#">Medicpin</a> All Rights Reserved.
                 </div>
              </div>
           </div>
        </footer>
        <!-- Footer END -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Medicpin\resources\views/pages/index.blade.php ENDPATH**/ ?>