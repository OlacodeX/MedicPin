<?php $__env->startComponent('mail::message'); ?>
# Hello Dr <?php echo e($data['from']); ?>,

 <p>This is to notify you that patient <?php echo e($data['name']); ?> with medicpin <?php echo e($data['pin']); ?> has been 
    successfully transferred to a new doctor.</p>
<br><br>
<p>Warm Regards,</p>
<p><strong>The Team at <?php echo e(config('app.name')); ?></strong></p>
<small>Have any complaint regarding our service or activities on our platform? Contact us on <a href="mailto:support@medicpin.com?Subject=Hello MedicPin, I Have an Enquiry">support@medicpin.com</a></small>
<?php echo $__env->renderComponent(); ?><?php /**PATH C:\xampp\htdocs\Medicpin\resources\views/emails/transfer.blade.php ENDPATH**/ ?>