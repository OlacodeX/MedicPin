<?php $__env->startSection('content'); ?>
<?php echo $__env->make('inc.navmaininner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <!-- Page Content  -->
         <div>
            <div class="">
               <div class="row">
                  <div class="col-lg-12">
                      <div class="container">
                        <div class="iq-card iq-card-block iq-card-stretch iq-card-height wow fadeInUp" data-wow-delay="0.6s">
                            <div class="iq-card-header d-flex justify-content-between">
                            <?php if(auth()->user()->role == 'Patient'): ?>
                            <div class="iq-header-title">
                                <h4 class="card-title">Dr. <?php echo Str::words( $notice->from_name,2); ?></h4>
                                <span><?php echo Str::words( $notice->created_at,5); ?></span>
                            </div>
                                
                            <?php endif; ?>
                            <?php if(auth()->user()->role == 'Doctor'): ?>
                            <div class="iq-header-title">
                                <h4 class="card-title"><?php echo Str::words( $notice->to_name,2); ?></h4>
                                <span><?php echo Str::words( $notice->created_at,5); ?></span>
                            </div>
                                
                            <?php endif; ?>
                            </div>
                            <div class="iq-card-body">
                                 <span><?php echo Str::words( $notice->content,50); ?></span>
                            </div>
                        </div>
                        
                      </div>
                  </div>
               </div>
            </div>
      <!-- Wrapper END -->
      <!-- Footer -->
        <footer class="bg-white iq-footer" style="margin-top:300px;">
            <div class="container-fluid">
               <div class="row">
                  <div class="col-lg-6">
                     <ul class="list-inline mb-0">
                        <li class="list-inline-item"><a href="privacy-policy.html">Privacy Policy</a></li>
                        <li class="list-inline-item"><a href="terms-of-service.html">Terms of Use</a></li>
                     </ul>
                  </div>
                  <div class="col-lg-6 text-right">
                     Copyright 2020 <a href="#">Medicpin</a> All Rights Reserved.
                  </div>
               </div>
            </div>
         </footer>
         <!-- Footer END -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.maininner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Medicpin\resources\views/notifications/show.blade.php ENDPATH**/ ?>