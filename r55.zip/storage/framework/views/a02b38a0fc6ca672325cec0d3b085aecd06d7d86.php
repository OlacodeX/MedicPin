<?php $__env->startComponent('mail::message'); ?>
#Dear <?php echo e($data['receiver_name']); ?>, You've got a new message.
<?php
    $hospital = App\hospitals::where('user_id',auth()->user()->id)->first();
?>
<p>Dr. <?php echo e(auth()->user()->name); ?> from <?php echo e($hospital->h_name); ?> <?php echo e($hospital->h_type); ?> hospital sent you the following message:</p>
<p><?php echo $data['message']; ?></p>
<p>Kindly head to your inbox to reply.</p>
<br><br>
<p>Warm Regards,</p>
<p><strong>The <?php echo e(config('app.name')); ?> Team</strong></p>
<small>Have any complaint regarding our service or activities on our platform? Contact us on <a href="mailto:support@medicpin.com?Subject=Hello MedicPin, I Have an Enquiry">support@medicpin.com</a></small>
<?php echo $__env->renderComponent(); ?><?php /**PATH C:\xampp\htdocs\Medicpin\resources\views/emails/message_doc.blade.php ENDPATH**/ ?>