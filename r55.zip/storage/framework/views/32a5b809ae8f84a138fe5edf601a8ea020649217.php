<?php $__env->startSection('content'); ?>
<?php echo $__env->make('inc.navmain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <!-- Page Content  -->
   <div>
    <div class="">

      <div class="row">
         <div class="col-12 col-lg-8">
          <div class="iq-card">
            <div class="iq-card-header">
             <h4 class="card-title"><strong>YOUR CART (<?php echo e(App\StoreCart::where('user_id', auth()->user()->id)->orderBy('id', 'ASC')->count()); ?> ITEMS)</strong></h4>
            </div>

            <div class="iq-card-body">
             <div class="table-responsive">
               <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
             <?php if(count($cartItems) > 0): ?>
                <table class="table product-overview">
                   <thead>
                      <tr>
                         <th>Image</th>
                         <th>Product info</th>
                         <th>Price</th>
                         <th>Quantity</th>
                         <!---<th>Status</th>--->
                         <th style="text-align:center">Action</th>
                      </tr>
                   </thead>
                   <tbody>
                     <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                         <td><img src="<?php echo e(URL::to('img/drugs/'.$cartItem->img)); ?>" alt="" width="80"></td>
                         <td>
                            <h5><?php echo e($cartItem->drug_name); ?></h5>
                            <p>
                              <?php echo e($cartItem->description); ?>

                            </p>
                         </td>
                         <td>&#8358;<?php echo e($cartItem->price); ?></td>
                         <td width="70">
                           <?php echo e($cartItem->quantity); ?>

                         </td>
                         <!----
                         <?php
                         $drug = App\pharmacy::find($cartItem->drug_id);
                        ?>
                     <?php if(empty($drug)): ?>
                     <td><?php echo e('Not Available'); ?></td>
                     <?php endif; ?>---->
                         <td align="center">
                            <style>
                               h4.card-title{
                                  padding-top: 15px;
                               }
                               a.btn.btn-danger{
                                  padding: 5px;
                               }
                            </style>
                           <?php echo Form::open(['action' => 'CartController@delete','id' => $cartItem->id,'method' => 'GET', 'class' => 'pull-left', 'style' => 'margin-right:20px;']); ?>

                           <?php echo e(Form::hidden('id', $cartItem->id)); ?>

                           <?php echo Form::close(); ?>

                            <a href="javascript:{}" onclick="document.getElementById(<?php echo e($cartItem->id); ?>).submit();" class="btn btn-danger" title="" data-toggle="tooltip" data-original-title="Delete"><i class="fa fa-trash-o"></i></a>
                           </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 					
                   </tbody>
                </table>   
                <div class="col-md-12" style="text-align:center;">
                        <!----- The pagination link----->
                        
                        <?php echo e($cartItems->links()); ?>

                </div>
                <?php else: ?>
                <p>You have no items in your cart yet</p>    
                <?php endif; ?>
                   <a href="<?php echo e(route('cart.checkout')); ?>" class="btn btn-lg btn-success pull-right" style="text-decoration: none;">
                     <i class="fa fa fa-shopping-cart"></i> Checkout
                   </a>
                   <a href="./pharmacist_shop" class="btn btn-lg btn-info" style="text-decoration: none;">
                     <i class="fa fa-arrow-left"></i> Continue Shopping 
                   </a>
             </div>

            </div>
          </div>
         </div>

         <div class="col-12 col-lg-4">
            <!--
          <div class="box">
            <div class="box-header bg-success">
             <h4 class="box-title"><strong>Discount</strong></h4>
            </div>
            <div class="box-body">
             <p>If you have any discount vouchers/coupans, apply here. If you don't have any, click <a href="javascript:void(0);" class="text-link">here</a> to get one.</p>
             <form class="form-inline mt-20">
                <div class="input-group w-p100">
                   <input type="text" class="form-control">
                   <div class="input-group-prepend">
                     <button type="button" class="btn btn-danger">Apply</button>
                   </div>--->
                   <!-- /btn-group -->
                   <!---
                </div>
             </form>

            </div>
          </div>			 
--->
          <div class="iq-card">
            <div class="iq-card-header">
             <h4 class="card-title"><strong>Cart Summary</strong></h4>
            </div>

            <div class="iq-card-body">
             <div class="table-responsive">
                <table class="table simple mb-0">
                   <tbody>
                      <tr>
                         <td>Total</td>
                         <td class="text-right font-weight-700">&#8358;<?php echo e(App\StoreCart::where('user_id', auth()->user()->id)->sum('price')); ?></td>
                      </tr>
                      <!---
                      <tr>
                         <td>Coupan Discount</td>
                         <td class="text-right font-weight-700"><span class="text-danger mr-15">50%</span>-$1620</td>
                      </tr>
                      <tr>
                         <td>Delivery Charges</td>
                         <td class="text-right font-weight-700">$50</td>
                      </tr>
                      <tr>
                         <td>Tax</td>
                         <td class="text-right font-weight-700">$18</td>
                      </tr>---->
                      <tr>
                         <th class="bt-1">Payable Amount</th>
                         <th class="bt-1 text-right font-weight-900 font-size-18">&#8358;<?php echo e(App\StoreCart::where('user_id', auth()->user()->id)->sum('price')); ?></th>
                      </tr>
                   </tbody>
                </table>
             </div>
            </div>
            <!---

            <div class="box-footer">	

             <button class="btn btn-lg btn-danger">Cancel Order</button>
             <button class="btn btn-lg btn-primary pull-right">Place Order</button>
            </div>--->
          </div> 
<!---
          <div class="box">
            <div class="box-header bg-dark">
             <h4 class="box-title"><strong>Support</strong></h4>
            </div>

            <div class="box-body">
             <h4 class="font-weight-800"><i class="ti-mobile"></i> +1800 123 8713 <span class="text-info">(Toll Free)</span></h4>
             <p>Contact us for any queries. We are avalible 24x7x365.</p>
            </div>
          </div>

         </div>--->

      </div>
                </div>
    </div>
 </div>
 <!-- Wrapper END -->
  <!-- Footer -->
    <footer class="bg-white iq-footer">
       <div class="container-fluid">
          <div class="row">
             <div class="col-lg-6">
                <ul class="list-inline mb-0">
                   <li class="list-inline-item"><a href="privacy-policy.html">Privacy Policy</a></li>
                   <li class="list-inline-item"><a href="terms-of-service.html">Terms of Use</a></li>
                </ul>
             </div>
             <div class="col-lg-6 text-right">
                Copyright 2020 <a href="./">Medicpin</a> All Rights Reserved.
             </div>
          </div>
       </div>
    </footer>
   </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Medicpin\resources\views/cart/index.blade.php ENDPATH**/ ?>