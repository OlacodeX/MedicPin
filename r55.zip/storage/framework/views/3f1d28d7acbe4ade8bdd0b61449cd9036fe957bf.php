
<?php $__env->startComponent('mail::message'); ?>
<?php if(!empty($data['name'])): ?>
# Hello <strong><?php echo e($data['name']); ?>,</strong>
<?php else: ?>
# Hello,
<?php endif; ?>
<p>We just want to notify you that Dr. <?php echo e(auth()->user()->name); ?> has created a record for you here on Medicpin. </p>
 #Further steps
 <p>To complete your account set up, click the button below</p>
 <p class="text-center"><a href="https://shielded-river-00274.herokuapp.com/account_set_up" class="btn btn-info">Continue Here</a><br>or copy and paste the link below in your browser</p>
 https://shielded-river-00274.herokuapp.com/account_set_up
<br><br>
<p>Warm Regards,</p>
<p><strong>The Team at <?php echo e(config('app.name')); ?></strong></p>
<small>Have any complaint regarding our service or activities on our platform? Contact us on <a href="mailto:support@medicpin.com?Subject=Hello MedicPin, I Have an Enquiry">support@medicpin.com</a></small>
<?php echo $__env->renderComponent(); ?><?php /**PATH C:\xampp\htdocs\Medicpin\resources\views/emails/patient.blade.php ENDPATH**/ ?>