<?php $__env->startComponent('mail::message'); ?>
# Hello MedicPin,
 <p>This is to notify you of a request from <?php echo e($data['name']); ?>.</p>
 <p>See request detail below:</p>
 <?php if( $data['b_group'] == '1500'): ?>
 <p><b>Blood Group </b> O+</p>  
 <?php endif; ?>
 <?php if( $data['b_group'] == '1600'): ?>
 <p><b>Blood Group </b> O-</p>  
 <?php endif; ?>
 <?php if( $data['b_group'] == '2000'): ?>
 <p><b>Blood Group </b> A+</p>  
 <?php endif; ?>
 <?php if( $data['b_group'] == '2500'): ?>
 <p><b>Blood Group </b> A-</p>  
 <?php endif; ?>
 <?php if( $data['b_group'] == '2100'): ?>
 <p><b>Blood Group </b> AB+</p>  
 <?php endif; ?>
 <?php if( $data['b_group'] == '5000'): ?>
 <p><b>Blood Group </b> AB-</p>  
 <?php endif; ?>
 
 <p><b>Quantity </b> <?php echo e($data['qty']); ?></p>
 <p><b>Hospital Name </b> <?php echo e($data['h_name']); ?></p>
 <p><b>Hospital Address </b> <?php echo e($data['add']); ?></p>
 <p><b>Phone Number </b> <a href="tel:<?php echo e($data['number']); ?>"><?php echo e($data['number']); ?></a></p>
 <p><b>Contact Email </b> <?php echo e($data['email']); ?></p>
 <p><b>Amount Payable </b> &#8358;<?php echo e($data['result']); ?></p>
<p>Cheers To Saving More Lives.</p>
<br>
<p>Warm Regards,</p>
<p><strong>The Team at <?php echo e(config('app.name')); ?></strong></p>
<?php echo $__env->renderComponent(); ?><?php /**PATH C:\xampp\htdocs\Medicpin\resources\views/emails/blood.blade.php ENDPATH**/ ?>