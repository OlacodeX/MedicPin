<?php $__env->startComponent('mail::message'); ?>
<?php
    $hmo = App\User::where('id', auth()->user()->id)->first();
?>
# Hi there,
# This is to notify you that the administrator at <?php echo e($hmo->hmo_org_name); ?> has rejected one of your claims request on medicpin. <br>
  <!---   Below are the patient's details: </p>
 <p>Name: <?php echo e(auth()->user()->name); ?></p>
 <p>Email: <?php echo e(auth()->user()->email); ?></p>
 <p>MedicPin: <?php echo e(auth()->user()->pin); ?></p>---->
 <p>Kindly head on to your dashboard and check your bills for further details.</p>
<br><br>
<p>Warm Regards,</p>
<p><strong>The Team at <?php echo e(config('app.name')); ?></strong></p>
<small>Have any complaint regarding our service or activities on our platform? Contact us on <a href="mailto:support@medicpin.com?Subject=Hello MedicPin, I Have an Enquiry">support@medicpin.com</a></small>
<?php echo $__env->renderComponent(); ?><?php /**PATH C:\xampp\htdocs\Medicpin\resources\views/emails/reject.blade.php ENDPATH**/ ?>