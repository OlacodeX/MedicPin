<?php $__env->startSection('content'); ?>
<?php echo $__env->make('inc.navmain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div>
    <div class="">
    <div class="row">
    <div class="col-sm-12" style="text-align:justify; margin-top:30px;">
      
      <div class="iq-card iq-card-block iq-card-stretch iq-card-height">
        <div class="iq-card-header d-flex justify-content-between">
           <div class="iq-header-title">
              <h4 class="card-title">Your Appointments </h4>
           </div>
           <div class="iq-card-header-toolbar d-flex align-items-center">
             <div class="dropdown">
                <span class="dropdown-toggle text-primary" id="dropdownMenuButton5" data-toggle="dropdown">
                <i class="ri-more-fill"></i>
                </span>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButton5">
                   <a class="dropdown-item" href="./appointments/create"><i class="las la-radiation"></i>Add New</a>
                </div>
             </div>
           </div>
        </div>
        <div class="iq-card-body">
           <div class="table-responsive">
              <?php if(auth()->user()->role == 'Patient'): ?>
              <?php
                  $appointmentss = App\Appointments::where('patient',auth()->user()->pin)->paginate(8);
              ?>
              <?php if(count($appointmentss) > 0): ?>
             <table class="table mb-0 table-borderless">
                <thead>
                   <tr>
                      <th scope="col">Doctor</th>
                      <th scope="col">Date</th>
                      <th scope="col">Time</th>
                      <th scope="col">Contact</th>
                      <th scope="col">Action</th>

                   </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $appointmentss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                       <?php
                           $patient = App\patients::where('pin', $appointment->patient)->first();
                           $doctor = App\User::where('pin', $appointment->doctor)->first();
                       ?>
                      <td><?php echo e($doctor->name); ?></td>
                      <td><?php echo e($appointment->date); ?></td>
                      <td><?php echo e($appointment->time); ?></td>
                      <td><a href="tel:<?php echo e($patient->phone); ?>" style="text-decoration: none;"><?php echo e($patient->phone); ?></a></td>
                      <td>
                        <div class="dropdown">
                           <span class="dropdown-toggle text-primary" id="dropdownMenuButton5" data-toggle="dropdown">
                           <i class="ri-more-fill"></i>
                           </span>
                           <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButton5">
                           <a class="dropdown-item" href="appointments/<?php echo e($appointment->id); ?>/edit">
                             <button class ="btn btn-info btn-sm" data-toggle="tooltip" data-placement="top" data-original-title="Edit Appointment"><i class="ri-pencil-fill mr-2"></i>Edit</button>
                           </a>
                           
                           <a class="dropdown-item">
                              <?php echo Form::open(['action' => ['PatientsController@destroy', $appointment->id], 'method' => 'POST', 'id' => 'my_form_1', 'style' => 'margin-right:20px;']); ?>

                              <?php echo e(Form::hidden('id', $appointment->id)); ?>

                              <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                              <button type="submit" class ="btn btn-info btn-sm" data-toggle="tooltip" data-placement="top" data-original-title="Delete Appointment"><i class="ri-delete-bin-6-fill mr-2"></i>Delete</button>
                             
                              <?php echo Form::close(); ?>

                           </a>
                           </div>
                        </div>
                          
                      </td>
                   </tr>
                  
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
             </table>
                 
           <div class="col-md-6">
               <div style="text-align:right;">
                       <!-----The pagination link----->
                       <?php echo e($appointmentss->links()); ?>

               </div>
           </div>
               <?php else: ?>
               <p>No Record Found</p>   
             <?php endif; ?>
            <?php else: ?>
            <?php
                $appointments = App\Appointments::where('doctor',auth()->user()->pin)->paginate(8);
            ?>
            <?php if(count($appointments) > 0): ?>
           <table class="table mb-0 table-borderless">
              <thead>
                 <tr>
                  <th scope="col">Patient's Pin</th>
                    <th scope="col">Patient</th>
                    <th scope="col">Doctor</th>
                    <th scope="col">Date</th>
                    <th scope="col">Time</th>
                    <th scope="col">Contact</th>
                    <th scope="col">Action</th>

                 </tr>
              </thead>
              <tbody>
                  <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr>
                     <?php
                         $patient = App\patients::where('pin', $appointment->patient)->first();
                         $doctor = App\User::where('pin', $appointment->doctor)->first();
                     ?>
                    <td><?php echo e($appointment->patient); ?></td>
                    <td><?php echo e($patient->name); ?></td>
                    <td><?php echo e($doctor->name); ?></td>
                    <td><?php echo e($appointment->date); ?></td>
                    <td><?php echo e($appointment->time); ?></td>
                    <td><a href="tel:<?php echo e($patient->phone); ?>" style="text-decoration: none;"><?php echo e($patient->phone); ?></a></td>
                    <td>
                      <div class="dropdown">
                         <span class="dropdown-toggle text-primary" id="dropdownMenuButton5" data-toggle="dropdown">
                         <i class="ri-more-fill"></i>
                         </span>
                         <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButton5">
                         <a class="dropdown-item" href="appointments/<?php echo e($appointment->id); ?>/edit">
                           <button class ="btn btn-info btn-sm" data-toggle="tooltip" data-placement="top" data-original-title="Edit Appointment"><i class="ri-pencil-fill mr-2"></i>Edit</button>
                         </a>
                         
                         <a class="dropdown-item">
                            <?php echo Form::open(['action' => ['PatientsController@destroy', $appointment->id], 'method' => 'POST', 'id' => 'my_form_1', 'style' => 'margin-right:20px;']); ?>

                            <?php echo e(Form::hidden('id', $appointment->id)); ?>

                            <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                            <button type="submit" class ="btn btn-info btn-sm" data-toggle="tooltip" data-placement="top" data-original-title="Delete Appointment"><i class="ri-delete-bin-6-fill mr-2"></i>Delete</button>
                           
                            <?php echo Form::close(); ?>

                         </a>
                         </div>
                      </div>
                        
                    </td>
                 </tr>
                
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
           </table>
               
         <div class="col-md-6">
             <div style="text-align:right;">
                     <!-----The pagination link----->
                     <?php echo e($appointments->links()); ?>

             </div>
         </div>
             <?php else: ?>
             <p>No Record Found</p>   
           <?php endif; ?>
           
              <?php endif; ?>
           </div>
        </div>
     </div>
  </div>
</div>

          <script src="<?php echo e(URL::asset('../vendor/unisharp/laravel-ckeditor/ckeditor.js')); ?>"></script>
          <script>
              CKEDITOR.replace( 'pre' );
          </script> 
     <!-- Wrapper END -->
      <!-- Footer -->
        <footer class="bg-white iq-footer" style="margin-top:280px;">
           <div class="container-fluid">
              <div class="row">
                 <div class="col-lg-6">
                    <ul class="list-inline mb-0">
                       <li class="list-inline-item"><a href="privacy-policy.html">Privacy Policy</a></li>
                       <li class="list-inline-item"><a href="terms-of-service.html">Terms of Use</a></li>
                    </ul>
                 </div>
                 <div class="col-lg-6 text-right">
                    Copyright 2020 <a href="#">Medicpin</a> All Rights Reserved.
                 </div>
              </div>
           </div>
        </footer>
        <!-- Footer END -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Medicpin\resources\views/appointments/index.blade.php ENDPATH**/ ?>