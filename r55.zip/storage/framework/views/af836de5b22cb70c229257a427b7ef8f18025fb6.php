<?php $__env->startSection('content'); ?>
<?php echo $__env->make('inc.navmain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
   <!-- Page Content  -->
   <div>
    <div class="">
       <div class="row">
          <div class="col-sm-12">
                <div class="iq-card">
                   <div class="iq-card-header d-flex justify-content-between">
                      <div class="iq-header-title">
                         <h4 class="card-title">Your Transfered Patients List</h4>
                      </div>
                   </div>
                   <div class="iq-card-body">
                      <div class="table-responsive">
                         <div class="row justify-content-between">
                              <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php if(count($users) > 0): ?>
                         <table id="user-list-table" class="table table-striped table-borderedless mt-4" role="grid" aria-describedby="user-list-page-info">
                           <thead>
                               
                               <tr>
                                  <th>Patient MedicPin</th>
                                  <th>Patient Name</th>
                                  <th>New Doctor</th>
                                  <th>New Doctor's MedicPin</th>
                                 <!--- <th>Action</th>--->
                               </tr>
                           </thead>


                           <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <tr>
                                  <td class="text-center"><?php echo e($user->pin); ?></td>
                                  <td><?php echo e($user->patient_name); ?></td>
                                  <td><?php echo e($user->to_doctor); ?></td>
                                  <td><?php echo e($user->doc_pin); ?></td>
                                  <!------
                                  <td>
                                    <?php echo Form::open(['action' => 'PatientsController@add_record', 'method' => 'POST', 'style' => 'margin-right:20px;']); ?>

                                    <?php echo e(Form::hidden('pin', $user->pin)); ?>

                                    <button type="submit" class ="btn btn-info btn-sm" >Add Medical Record</button>
                                   
                                    <?php echo Form::close(); ?>

                                    <?php echo Form::open(['action' => 'RecordsController@index', 'method' => 'GET', 'style' => 'margin-right:20px;']); ?>

                                    <?php echo e(Form::hidden('pin', $user->pin)); ?>

                                    <?php echo e(Form::hidden('username', $user->username)); ?>

                                    <button type="submit" class ="btn btn-info btn-sm" >Check Medical Records</button>
                                   
                                    <?php echo Form::close(); ?>

                                    <?php echo Form::open(['action' => 'PatientsController@transfer', 'method' => 'POST', 'style' => 'margin-right:20px;']); ?>

                                    <?php echo e(Form::hidden('pin', $user->pin)); ?>

                                    <button type="submit" class ="btn btn-info btn-sm" >Transfer Patient</button>
                                   
                                    <?php echo Form::close(); ?>

                                    <?php echo Form::open(['action' => 'MessagingController@create', 'method' => 'GET', 'style' => 'margin-right:20px;']); ?>

                                    <?php echo e(Form::hidden('pin', $user->pin)); ?>

                                    <button type="submit" class ="btn btn-info btn-sm" title="Message Patient">Message Patient</button>
                                   
                                    <?php echo Form::close(); ?>

                                     <div class="flex align-items-center list-user-action">
                                        <?php echo Form::open(['action' => ['PatientsController@destroy', $user->id], 'method' => 'POST', 'id' => 'my_form_1', 'style' => 'margin-right:20px;']); ?>

                                        <?php echo e(Form::hidden('email', $user->email)); ?>

                                        <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                                        <button type="submit" class ="btn btn-info btn-sm" >Delete Patient</button>
                                       
                                        <?php echo Form::close(); ?>

                                     </div>
                                  </td>
                                  ----->
                               </tr> 
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                      
                           </tbody>
                         </table>
                      </div>
                            <div class="col-md-6">
                                <div style="text-align:right;">
                                        <!-----The pagination link----->
                                        <?php echo e($users->links()); ?>

                                </div>
                                <?php else: ?>
                                <p>No Record Found</p>    
                                <?php endif; ?>
                            </div>
                         </div>
                   </div>
                </div>
          </div>
       </div>
    </div>
 <!-- Wrapper END -->
  <!-- Footer -->
    <footer class="bg-white iq-footer">
       <div class="container-fluid">
          <div class="row">
             <div class="col-lg-6">
                <ul class="list-inline mb-0">
                   <li class="list-inline-item"><a href="privacy-policy.html">Privacy Policy</a></li>
                   <li class="list-inline-item"><a href="terms-of-service.html">Terms of Use</a></li>
                </ul>
             </div>
             <div class="col-lg-6 text-right">
                Copyright 2020 <a href="./">Medicpin</a> All Rights Reserved.
             </div>
          </div>
       </div>
    </footer>
    <!-- Footer END -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Medicpin\resources\views/patients/transfer_list.blade.php ENDPATH**/ ?>