<?php $__env->startSection('page_title'); ?>
<?php echo e(config('app.name')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('inc.homestyle', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid main">
    <div class="container">
        <div class="col-sm-8">
            <h1 class="spot">Medicpin EHR SERVICES</h1>
            <p class="text-justify">
                We are not about just being paperless, 
                but built for the cloud. 
                Our platform is about simplifying working with intelligent System that
                 help doctors to work efficiently and enhance Patient care over the cloud.
            </p>
            <p class="btn btn-info">
                Manage appointments, access medical records anytime, anywhere and lots more....
            </p>
            <p class="btn btn-info">
                Migrate from paper records to cloud data management....
            </p>
            <p class="btn btn-info">
               Fast, Secure and Reliable....
            </p>
            <!-- Authentication Links -->
            <?php if(auth()->guard()->guest()): ?>
            
            <p><a href="<?php echo e(route('register')); ?>" class="btn btn-success btn-lg pull-left">SIGN UP NOW</a><a href="<?php echo e(route('login')); ?>" class="btn btn-success btn-lg pull-right transparent">SIGN IN HERE</a></p>
            <?php else: ?>
            <p><a href="./dashboard" class="btn btn-success btn-lg pull-left">Go To Dashboard</a></p>
            <?php endif; ?>
        </div>
        <div class="col-sm-4">
            <img src="img/cope.png" alt="" class="img-responsive">
        </div>
</div>
<script>
    var msg = '<?php echo e(Session::get('alert')); ?>';
    var exist = '<?php echo e(Session::has('alert')); ?>';
    if(exist){
      alert(msg);
    }
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainn', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Medicpin\resources\views/pages/home.blade.php ENDPATH**/ ?>