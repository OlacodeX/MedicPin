<?php $__env->startComponent('mail::message'); ?>
<?php
    $user = App\User::where('pin', auth()->user()->pin)->first();
?>
<?php if(empty($user->h_id)): ?>
# Hi,
<p>This is to notify you that patient <?php echo e(auth()->user()->name); ?> has invited you to visit them on <?php echo e($data['date']); ?>.</p>
<?php endif; ?>
<?php if(!empty($user->h_id)): ?>
<?php
    $user = App\User::where('pin', auth()->user()->pin)->first();
    $hospital = App\hospitals::where('id', $user->h_id)->first();
?>
# Hi,
 <p>This is to notify you that patient <?php echo e(auth()->user()->name); ?> from <?php echo e($hospital->h_name); ?> <?php echo e($hospital->h_type); ?> hospital located at <?php echo e($hospital->h_add); ?> has invited you to visit them on <?php echo e($data['date']); ?>.</p>
 <?php endif; ?>
 <p>Please come along with a copy of this message.</p>
<br><br>
<p>Warm Regards,</p>
<p><strong>The Team at <?php echo e(config('app.name')); ?></strong></p>
<small>Have any complaint regarding our service or activities on our platform? Contact us on <a href="mailto:support@medicpin.com?Subject=Hello MedicPin, I Have an Enquiry">support@medicpin.com</a></small>
<?php echo $__env->renderComponent(); ?><?php /**PATH C:\xampp\htdocs\Medicpin\resources\views/emails/visitor.blade.php ENDPATH**/ ?>