<?php $__env->startSection('content'); ?>
<?php echo $__env->make('inc.navmain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <!-- Page Content  -->
     <div>
        <div class="">
                    <div class="iq-card">
                     <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                       <div class="iq-card-header d-flex justify-content-between">
                          <div class="iq-header-title">
                             <h4 class="card-title">Add Staff To HMO Package</h4>
                          </div>
                       </div>
                       <div class="iq-card-body">
              
                       <?php echo Form::open(['action' => 'HmoController@complete_add', 'method' => 'POST']) /** The action should be the block of code in the store function in PostsController
                       **/; ?>

                      <div class="row">
                        <div class="form-group col-md-6">
                           <label for="email">Email</label>
                           <div class="inner-addon right-addon">
                               <i class="fa fa-envelope"></i>
                               <?php if(auth()->user()->role == 'Patient'): ?>
                               <input type="text" class="form-control" value="<?php echo e(auth()->user()->email); ?>" name="email" id="email" placeholder="Email" readonly>
    
                              <?php else: ?>       
                              <input type="text" class="form-control" value="<?php echo e($email); ?>" name="email" id="email" placeholder="Email" readonly>
                               
                              <?php endif; ?>
                         </div>
                        </div>
                        <?php
                            $hmos = App\User::where('role', 'HMO')->get();
                        ?>
                            <div class="form-group col-md-6">
                              <label for="hmo">HMO Name</label>
                              <select class="form-control" id="selecthmo" name="hmo">
                                 <option>---Select hmo---</option>
                                 <?php if(count($hmos) > 0): ?>
                                 <?php $__currentLoopData = $hmos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hmo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <option value="<?php echo e($hmo->id); ?>"><?php echo e($hmo->hmo_org_name); ?></option>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 <?php else: ?>
                                     
                                 <option>No record found</option>
                                 <?php endif; ?>
                              </select>
                            </div>
                         </div>
                         <hr>
                         <!----
                         <h5 class="mb-3">Medical Records</h5>
                         <div class="row">
                             <div class="form-group col-md-6">
                                <label for="Blood Group">Blood Group</label>
                                <select class="form-control" id="selectbg" name="b_group">
                                   <option>Select</option>
                                   <option value="O+">O+</option>
                                   <option value="AB+">AB+</option>
                                   <option value="AB+">AB+</option>
                                   <option value="AB+">AB+</option>
                                   <option value="AB+">AB+</option>
                                </select>
                             </div>
                             <div class="form-group col-md-6">
                                <label for="bp">Blood Pressure</label>
                                <input type="text" class="form-control" id="bp" name="bp" placeholder="Blood Pressure">
                             </div>
                             <div class="form-group col-md-6">
                                <label for="h_rate">Heart Rate</label>
                                <input type="text" class="form-control" id="h_rate" name="h_rate" placeholder="Heart Rate">
                             </div>
                             <div class="form-group col-md-6">
                                <label for="genotype">Genotype</label>
                                <select class="form-control" id="selectgenotype" name="genotype">
                                   <option>Select</option>
                                   <option value="AA">AA</option>
                                   <option value="AS">AS</option>
                                   <option value="SS">SS</option>
                                </select>
                             </div>
                             <div class="form-group col-md-6">
                                <label for="weight">Weight</label>
                                <input type="text" class="form-control" id="weight" name="weight" placeholder="Weight">
                             </div>
                             <div class="form-group col-md-6">
                                <label for="height">Height</label>
                                <input type="text" class="form-control" id="height" name="height" placeholder="Height">
                             </div>
                             <div class="form-group col-md-6">
                                <label for="temprature">Temperature</label>
                                <input type="text" class="form-control" id="temprature" name="temprature" placeholder="Temprature">
                             </div>
                         </div>
                         ----->
                         <button type="submit" class="btn btn-primary">Continue</button>
                         <?php echo Form::close(); ?>

                       </div>
                    </div>
     <!-- Wrapper END -->
      <!-- Footer -->
        <footer class="bg-white iq-footer" style="margin-top:80px;">
           <div class="container-fluid">
              <div class="row">
                 <div class="col-lg-6">
                    <ul class="list-inline mb-0">
                       <li class="list-inline-item"><a href="privacy-policy.html">Privacy Policy</a></li>
                       <li class="list-inline-item"><a href="terms-of-service.html">Terms of Use</a></li>
                    </ul>
                 </div>
                 <div class="col-lg-6 text-right">
                    Copyright 2020 <a href="#">Medicpin</a> All Rights Reserved.
                 </div>
              </div>
           </div>
           <script src="<?php echo e(URL::asset('../vendor/unisharp/laravel-ckeditor/ckeditor.js')); ?>"></script>
           <script>
           CKEDITOR.replace( 'value' );
           </script> 
          
        </footer>
        <!-- Footer END -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Medicpin\resources\views/pages/hmo.blade.php ENDPATH**/ ?>