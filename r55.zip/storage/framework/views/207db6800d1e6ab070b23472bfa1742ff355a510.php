<?php $__env->startSection('content'); ?>
<?php echo $__env->make('inc.navmaininner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <div>
          <div class="">
    <div class="row" style="padding-bottom: 100px;padding-left:20px;">
    <div class="col-sm-9" style="text-align:justify;">
      <h3 class="title"><span><?php echo e($message->sender_name); ?></span></h3>
      <small><i class="fa fa-calendar"></i><?php echo $message->created_at; ?></small>
      <hr>
      <p><?php echo $message->message; ?></p>
      
      <h3 class="title">Reply <span><?php echo e($message->sender_name); ?></span></h3>
      <?php echo Form::open(['action' => 'MessagingController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']) /** The action should be the block of code in the store function in PostsController
      **/; ?>

      <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
       <div class="form-group">
         <?php echo e(Form::textarea('message', '', ['class' => 'form-control', 'id' =>'pre'], 'required')); ?>

       </div>
       <?php
           $sender = App\User::where('id', $message->sender_id)->first();
       ?>
       <?php echo e(Form::hidden('receiver_pin', $sender->pin)); ?>

       <?php echo e(Form::hidden('receiver_id', $message->sender_id)); ?>

       <?php echo e(Form::hidden('receiver_email', $message->sender_email)); ?>

       <?php echo e(Form::hidden('receiver_name', $message->sender_name)); ?>

       <?php echo e(Form::hidden('message_id', $message->id)); ?>

       <?php echo e(Form::submit('Reply', ['class' => 'btn btn-primary btn-md pull-left', 'style' => 'text-transform:uppercase;'])); ?>

      <?php echo Form::close(); ?>

      <a href="../chat" class="btn btn-primary btn-md pull-right">Back</a><br>
    </div>
</div>
</div>

</div>

          <script src="<?php echo e(URL::asset('../vendor/unisharp/laravel-ckeditor/ckeditor.js')); ?>"></script>
          <script>
              CKEDITOR.replace( 'pre' );
          </script> 
                      <hr>
     <!-- Wrapper END -->
      <!-- Footer -->
        <footer class="bg-white iq-footer">
           <div class="container-fluid">
              <div class="row">
                 <div class="col-lg-6">
                    <ul class="list-inline mb-0">
                       <li class="list-inline-item"><a href="privacy-policy.html">Privacy Policy</a></li>
                       <li class="list-inline-item"><a href="terms-of-service.html">Terms of Use</a></li>
                    </ul>
                 </div>
                 <div class="col-lg-6 text-right">
                    Copyright 2020 <a href="#">Medicpin</a> All Rights Reserved.
                 </div>
              </div>
           </div>
        </footer>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.maininner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Medicpin\resources\views/chat/show.blade.php ENDPATH**/ ?>