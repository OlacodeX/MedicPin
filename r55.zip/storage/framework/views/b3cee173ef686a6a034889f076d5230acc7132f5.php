<?php $__env->startComponent('mail::message'); ?>
#Hi there,
<p><?php echo e(auth()->user()->name); ?> asked the following question on the forum:</p>
<p><?php echo $data['question']; ?></p>
<p>We would appreciate your professional response.</p>
<?php
    $question = App\Questions::where('question', $data['question'])->first();
?>
<a href="<?php echo e(config('app.url')); ?>/questions/<?php echo e($question->id); ?>">Follow this link to answer.</a>
<br><br>
<p>Warm Regards,</p>
<p><strong>The <?php echo e(config('app.name')); ?> Team</strong></p>
<small>Have any complaint regarding our service or activities on our platform? Contact us on <a href="mailto:support@medicpin.com?Subject=Hello MedicPin, I Have an Enquiry">support@medicpin.com</a></small>
<?php echo $__env->renderComponent(); ?><?php /**PATH C:\xampp\htdocs\Medicpin\resources\views/emails/question.blade.php ENDPATH**/ ?>