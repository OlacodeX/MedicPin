<?php $__env->startSection('content'); ?>
<?php echo $__env->make('inc.navmain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <!-- Page Content  -->
         <div>
            <div class="">
               <div class="row">
                  <div class="col-md-12">
                    <?php if(count($drugs) > 0): ?>
                    
                     <div class="iq-card">
                        <div class="iq-card-header d-flex justify-content-between">
                         <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                           <div class="iq-header-title">
                              <h4 class="card-title">Drug Inventory</h4>
                           </div>
                        </div>
                        <div class="iq-card-body">
                           <!----
                           <table id="user-list-table" class="table table-striped table-bordered mt-4" role="grid" aria-describedby="user-list-page-info">
                             <thead>
                                 
                              <style>
                                 span.pull-right{
                                     font-size: 10px;
                                     color: #0084ff;
                                 }
                                 span.pull-right.in{
                                     font-size: 10px;
                                     color: #4ff84f;
                                 }
                                 span.pull-right.out{
                                     font-size: 10px;
                                     color: #fa1414;
                                                  }
                                                  
                                   
                                                  .btn.btn-info.btn-sm{
                                      background: transparent;
                                      border: none;
                                      color: rgb(20, 109, 224);

                                   }
                                   .btn.btn-info.btn-sm i.fa{
                                      font-size: 12px;
                                      margin: 0;
                                   }
                                   .product-description{
                                      padding-bottom:50px;
                                   }
                @media  only screen and (max-width: 768px) {
                   
                  .btn.btn-info.btn-sm{
                      background: transparent;
                      border: none;
                      color: rgb(20, 109, 224);
                      float: right;
                      display: inline;
                  }
                  
                  .btn.btn-info.btn-sm i.fa{
                      font-size: 12px;
                      margin: 0;
                      padding: 0;
                  }
                                   .product-description{
                                      padding-bottom:80px;
                                   }
                }
                             </style>
                                 <tr>
                                    <th>Drug Name</th>
                                    <th>Price</th>
                                    <th>Action(s)</th>
                                 </tr>
                             </thead>
                             <tbody>
                               <?php $__currentLoopData = $drugs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drug): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <tr>
                                    <td>
                                       <?php echo e($drug->name); ?> 
                                       <?php if($drug->status == 'In Stock'): ?>
                                       <span class="pull-right in"><?php echo e($drug->status); ?></span>
                                       <?php endif; ?>
                                       <?php if($drug->status == 'Out Of Stock'): ?>
                                       <span class="pull-right out"><?php echo e($drug->status); ?></span>
                                       <?php endif; ?>
                                    </td>
                                    <td>
                                       ₦<?php echo e($drug->price); ?>/Pack
                                    </td>
                                    <td>
                                       <div class="dropdown">
                                          <span class="dropdown-toggle text-primary" id="dropdownMenuButton5" data-toggle="dropdown">
                                          <i class="ri-more-fill"></i>
                                          </span>
                                          <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButton5">
                                                   <a class="dropdown-item">
                                                <?php echo Form::open(['action' => 'PatientsController@edit_drug', 'method' => 'POST', 'style' => 'margin-right:20px;']); ?>

                                                <?php echo e(Form::hidden('id', $drug->id)); ?>

                                                <button type="submit" class ="btn btn-info btn-sm" title="Edit Drug Details"><i class="fa fa-edit"></i></button>
                                             
                                                <?php echo Form::close(); ?>

                                             </a>
                                          
                                         <?php if($drug->status == 'In Stock'): ?>
                                          <a class="dropdown-item">
                                                <?php echo Form::open(['action' => 'PatientsController@status_change', 'method' => 'POST', 'style' => 'margin-right:20px;']); ?>

                                                <?php echo e(Form::hidden('id', $drug->id)); ?>

                                                <button type="submit" class ="btn btn-info btn-sm" title="Mark As Out Of Stock"><i class="fa fa-check-circle"></i></button>
                                             
                                                <?php echo Form::close(); ?>

                                             </a>
                                             <?php endif; ?>
                                          
                                          <a class="dropdown-item">
               
               
                                                   <?php echo Form::open(['action' => 'PatientsController@destroy_drug', 'method' => 'POST', 'id' => 'my_form_1', 'style' => 'margin-right:20px;']); ?>

                                                   <?php echo e(Form::hidden('id', $drug->id)); ?>

                                                   <button type="submit" class ="btn btn-info btn-sm" title="Delete Drug"><i class="fa fa-trash-o"></i></button>
                                                   
                                                   <?php echo Form::close(); ?>

                                                </a>
                                          </div>
                                       </div>
                                         
                                        
                                   </td>
                                     </tr>
                                   
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>           
                             </tbody>
                           </table>
                           ----->
                           <div id="js-product-list">
                              <div class="Products">
                                 <ul class="product_list gridcount grid row">
                                    <?php $__currentLoopData = $drugs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drug): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="product_item col-xs-12 col-sm-6 col-md-6 col-lg-3" style="list-style: none;">
                                       <a href="javascript:{}" onclick="document.getElementById(<?php echo e($drug->id); ?>).submit();">
                                       <div class="product-miniature">
                                          <div class="thumbnail-container">
                                             <img src="<?php echo e(URL::to('img/drugs/'.$drug->img)); ?>" alt="product-image" class="img-fluid" />                                             
                                          </div>
                                          <style>
                                            div.product-miniature{
                                               margin-bottom: 20px;
                                               padding: 8px;
                                               height: 350px;
                                               box-shadow: 2px 5px 3px 5px rgba(236, 236, 236, 0.2);

                                            } 
                                            div.product-miniature div.thumbnail-container img{
                                               height: 200px;
                                                width: 500px;
                                            }
                                              span.pull-right{
                                                  font-size: 10px;
                                                  color: #0084ff;
                                              }
                                              span.pull-right.in{
                                                  font-size: 10px;
                                                  color: #4ff84f;
                                              }
                                              span.pull-right.out{
                                                  font-size: 10px;
                                                  color: #fa1414;
                                                               }
                                                               
                                                
                                                               .btn.btn-info.btn-sm{
                                                   background: transparent;
                                                   border: none;
                                                   color: rgb(20, 109, 224);

                                                }
                                                .btn.btn-info.btn-sm i.fa{
                                                   font-size: 12px;
                                                   margin: 0;
                                                }
                                                .product-description{
                                                   padding-bottom:90px;
                                                   padding-top: 10px;
                                                }
                             @media  only screen and (max-width: 768px) {
                                            .product-miniature{
                                               margin-bottom: 20px;
                                               padding: 8px;
                                               height: 480px;
                                               box-shadow: 2px 5px 3px 5px rgba(236, 236, 236, 0.2);

                                            } 
                                
                               .btn.btn-info.btn-sm{
                                   background: transparent;
                                   border: none;
                                   color: rgb(20, 109, 224);
                                   float: right;
                                   display: inline;
                               }
                               
                               .btn.btn-info.btn-sm i.fa{
                                   font-size: 12px;
                                   margin: 0;
                                   padding: 0;
                               }
                                                .product-description{
                                                   padding-bottom:80px;
                                                }
                             }
                                          </style>
                                          <div class="product-description">
                                             <?php echo Form::open(['action' => 'PatientsController@get_drug', 'method' => 'POST', 'id' => $drug->id, 'style' => 'margin-right:20px;']); ?>

                                             <?php echo e(Form::hidden('id', $drug->id)); ?>

                                             <?php echo Form::close(); ?>

                                             <h4>
                                                <?php echo e($drug->name); ?> 
                                                <?php if($drug->status == 'In Stock'): ?>
                                                <span class="pull-right in"><?php echo e($drug->status); ?></span>
                                                <?php endif; ?>
                                                <?php if($drug->status == 'Out Of Stock'): ?>
                                                <span class="pull-right out"><?php echo e($drug->status); ?></span>
                                                <?php endif; ?>
                                             </h4> 
                                             <div class="d-flex flex-wrap justify-content-between align-items-center">
                                                <!---
                                                <div class="product-action">
                                                   <div class="add-to-cart">
                                                      <a href="<?php echo e(route('cart.add', $drug->id)); ?>" data-toggle="tooltip" data-placement="top" title="" data-original-title="Add to Cart"> <i class="ri-shopping-cart-2-line"></i> </a>
                                                      
                                                   </div>
                                                </div>-->
                                                <div class="product-price">
                                                   <div class="regular-price"><b>₦<?php echo e($drug->price); ?>/Pack</b></div>
                                                </div>
                                                <?php
                                                    $user = App\User::where('pin', $drug->doc_pin)->first();
                                                ?>
                                                <?php if($user->h_id == auth()->user()->h_id && auth()->user()->role == 'Pharmacist'): ?>
                                                <div class="text-center">
                                                <span class="user-list-files d-flex float-right">
                                                <?php echo Form::open(['action' => 'PatientsController@edit_drug', 'method' => 'POST', 'style' => 'margin-right:20px;']); ?>

                                                <?php echo e(Form::hidden('id', $drug->id)); ?>

                                                <button type="submit" class ="btn btn-info btn-sm" data-toggle="tooltip" data-placement="top" data-original-title="Edit Drug Details"><i class="fa fa-edit"></i></button>
                                             
                                                <?php echo Form::close(); ?>

                                                <?php echo Form::open(['action' => 'PatientsController@status_change', 'method' => 'POST', 'style' => 'margin-right:20px;']); ?>

                                                <?php echo e(Form::hidden('id', $drug->id)); ?>

                                                <button type="submit" class ="btn btn-info btn-sm" data-toggle="tooltip" data-placement="top" data-original-title="Mark As Out Of Stock"><i class="fa fa-check-circle"></i></button>
                                             
                                                <?php echo Form::close(); ?>

               
               
                                                   <?php echo Form::open(['action' => 'PatientsController@destroy_drug', 'method' => 'POST', 'id' => 'my_form_1', 'style' => 'margin-right:20px;']); ?>

                                                   <?php echo e(Form::hidden('id', $drug->id)); ?>

                                                   <button type="submit" class ="btn btn-info btn-sm" data-toggle="tooltip" data-placement="top" data-original-title="Delete Drug"><i class="fa fa-trash-o"></i></button>
                                                   
                                                   <?php echo Form::close(); ?>

                                                </span>
                                                </div>
                                                   <?php endif; ?>
                                          </div>
                                       </div>
                                    </a> 
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                 </ul>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-md-6">
                         <div>
                                 <!-----The pagination link----->
                                 <?php echo e($drugs->links()); ?>

                         </div>
                         <?php else: ?>
                         <p>No Drugs In Stock Yet, Please Check Back Later.</p>    
                         <?php endif; ?>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- Wrapper END -->
      <!-- Footer -->
        <footer class="bg-white iq-footer" style="margin-top: 300px;">
            <div class="container-fluid">
               <div class="row">
                  <div class="col-lg-6">
                     <ul class="list-inline mb-0">
                        <li class="list-inline-item"><a href="privacy-policy.html">Privacy Policy</a></li>
                        <li class="list-inline-item"><a href="terms-of-service.html">Terms of Use</a></li>
                     </ul>
                  </div>
                  <div class="col-lg-6 text-right">
                     Copyright 2020 <a href="#">Medicpin</a> All Rights Reserved.
                  </div>
               </div>
            </div>
         </footer>
         <!-- Footer END -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Medicpin\resources\views/patients/ph.blade.php ENDPATH**/ ?>